# minibus-done > 2023-09-14 12:03am
https://universe.roboflow.com/2-kendaraan-tia/minibus-done

Provided by a Roboflow user
License: Public Domain

